/* SPORE GBA - Etapa Celular
 * Etapa 1: motor (Modo 4 + buffer en EWRAM), fuente, fondo, pantalla de titulo.
 * Sin librerias externas: solo registros de hardware.
 */
typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
typedef signed short   s16;

#include "data.h"

#define SW 240
#define SH 160
#define REG16(a) (*(volatile u16 *)(a))
#define REG32(a) (*(volatile u32 *)(a))
#define EWRAM __attribute__((section(".ewram"), aligned(4)))

#define REG_DISPCNT REG16(0x04000000)
#define REG_VCOUNT  REG16(0x04000006)
#define REG_KEYS    REG16(0x04000130)
#define DMA3_SRC    REG32(0x040000D4)
#define DMA3_DST    REG32(0x040000D8)
#define DMA3_CNT    REG32(0x040000DC)
#define PAL_RAM     ((volatile u16 *)0x05000000)
#define VRAM        ((volatile u16 *)0x06000000)

enum { K_A = 1, K_B = 2, K_SEL = 4, K_START = 8, K_R = 16, K_L = 32, K_U = 64, K_D = 128, K_RT = 256, K_LT = 512 };

/* ---------- paleta ---------- */
enum {
    C_BLK = 0, C_BG0, C_BG1, C_BG2, C_BG3, C_BG4,          /* 1-5 fondo */
    C_WHT, C_YEL, C_CYN, C_PNL, C_PNB, C_SEL, C_TXT, C_TX2,
    C_GRN, C_DGR, C_LGR, C_ORB, C_BUB, C_BUD, C_PNK, C_PNL2,
    C_PNK3, C_EYE, C_HLP, C_FIL1, C_FIL2, C_FIL3, C_EYED, C_ORG,
    C_CELL = 32                                           /* 32.. = 6 colores x 4 tonos */
};
static const u32 COLS[] = {
    0x02050c, 0x050c1e, 0x081834, 0x0c2a50, 0x16466e, 0x32708c,
    0xffffff, 0xffe060, 0x4cc4e8, 0x07132b, 0x1c4f86, 0x1c5a9a, 0x7ab4d8, 0x9ad0f0,
    0x8cf0a0, 0x0b3a2a, 0xd8ffd8, 0x402000, 0xbff4ff, 0x6aa8bc, 0xff8ab8, 0xffd0e4,
    0xc0507f, 0xbbccdd, 0xcfe8ff, 0xa8e8ff, 0x4aa0c8, 0xe0ffff, 0x111111, 0xe08020,
};
static const u32 CELLP[6][4] = {
    {0x2f8f4e, 0x58c46a, 0xa8f0a0, 0x145a34}, {0xb83a78, 0xe866a0, 0xffb0d0, 0x6a1a48},
    {0x2f66c0, 0x58a0f0, 0xb0dcff, 0x183a80}, {0xc8661e, 0xf09a3c, 0xffd48c, 0x703010},
    {0x6a3ab8, 0x9a68e8, 0xd0b0ff, 0x381a78}, {0xb8a21e, 0xe8d84c, 0xfff8a0, 0x6a5c10},
};
static u16 rgb15(u32 c) { return (u16)(((c >> 19) & 31) | (((c >> 11) & 31) << 5) | (((c >> 3) & 31) << 10)); }
static void init_palette(void) {
    for (unsigned i = 0; i < sizeof COLS / sizeof COLS[0]; i++) PAL_RAM[i] = rgb15(COLS[i]);
    for (int p = 0; p < 6; p++) for (int s = 0; s < 4; s++) PAL_RAM[C_CELL + p * 4 + s] = rgb15(CELLP[p][s]);
}

/* ---------- buffers y video ---------- */
static u8 fb[SW * SH] EWRAM; /* lienzo de trabajo */

static void dma32(void *dst, const void *src, u32 words) {
    DMA3_SRC = (u32)src; DMA3_DST = (u32)dst;
    DMA3_CNT = words | (1u << 31) | (1u << 26);
}
static void vsync(void) { while (REG_VCOUNT >= 160) {} while (REG_VCOUNT < 160) {} }
static void present(void) { vsync(); dma32((void *)VRAM, fb, SW * SH / 4); }

/* ---------- entrada ---------- */
static u16 keys, pressed;
static void poll(void) { u16 k = (u16)(~REG_KEYS & 0x3FF); pressed = k & ~keys; keys = k; }

/* ---------- utilidades ---------- */
static int sn(int a) { return SINTAB[a & 255]; }        /* seno  Q8, 256 = vuelta */
static int cs(int a) { return SINTAB[(a + 64) & 255]; } /* coseno Q8 */
static u32 rs = 12345;
static int rnd(int n) { rs = rs * 1664525u + 1013904223u; return (int)((rs >> 16) % (u32)n); }
static int tm;

/* ---------- primitivas ---------- */
static void px(int x, int y, u8 c) { if ((unsigned)x < SW && (unsigned)y < SH) fb[y * SW + x] = c; }
static void rect(int x, int y, int w, int h, u8 c) {
    int x1 = x + w, y1 = y + h;
    if (x < 0) { x = 0; }
    if (y < 0) { y = 0; }
    if (x1 > SW) { x1 = SW; }
    if (y1 > SH) { y1 = SH; }
    for (int j = y; j < y1; j++) for (int i = x; i < x1; i++) fb[j * SW + i] = c;
}
static int tw(const char *s, int z) { int n = 0; while (s[n]) n++; return n * 4 * z - z; }
static int fidx(char ch) { for (int i = 0; i < FONT_N; i++) if (FONT_CH[i] == ch) return i; return -1; }
static int text(const char *s, int x, int y, u8 c, int z) {
    for (; *s; s++, x += 4 * z) {
        int i = fidx(*s); if (i < 0) continue;
        for (int r = 0; r < 5; r++) for (int q = 0; q < 3; q++)
            if ((FONT_D[i][r] >> (2 - q)) & 1) rect(x + q * z, y + r * z, z, z, c);
    }
    return x;
}
static void text_sh(const char *s, int x, int y, u8 c, int z, u8 sh) {
    int o = z > 2 ? 2 : 1; text(s, x + o, y + o, sh, z); text(s, x, y, c, z);
}
static void text_c(const char *s, int cx, int y, u8 c, int z, int sh) {
    int x = cx - tw(s, z) / 2; if (sh >= 0) text_sh(s, x, y, c, z, (u8)sh); else text(s, x, y, c, z);
}
static void panel(int x, int y, int w, int h) {
    rect(x + 1, y + 1, w - 2, h - 2, C_PNL);
    rect(x + 1, y, w - 2, 1, C_CYN); rect(x + 1, y + h - 1, w - 2, 1, C_CYN);
    rect(x, y + 1, 1, h - 2, C_CYN); rect(x + w - 1, y + 1, 1, h - 2, C_CYN);
    rect(x + 2, y + 1, w - 4, 1, C_PNB);
}
static void bubble(int x, int y, int r) {
    for (int dy = -r; dy <= r; dy++) for (int dx = -r; dx <= r; dx++) {
        int d = dx * dx + dy * dy;
        if (d <= r * r + r && d > (r - 1) * (r - 1)) px(x + dx, y + dy, C_BUD);
    }
    if (r > 1) px(x - (r >> 1), y - (r >> 1), C_BUB);
}

/* ---------- burbujas flotantes ---------- */
#define NB 14
static struct { int x, y, s, r; } bu[NB]; /* y en Q4 */
static void init_bubbles(void) {
    for (int i = 0; i < NB; i++) { bu[i].x = rnd(SW); bu[i].y = rnd(SH + 20) << 4; bu[i].s = 3 + rnd(6); bu[i].r = 1 + rnd(3); }
}
static void draw_bubbles(void) {
    for (int i = 0; i < NB; i++) {
        bu[i].y -= bu[i].s;
        if ((bu[i].y >> 4) < -8) { bu[i].y = (SH + 8) << 4; bu[i].x = rnd(SW); }
        bubble(bu[i].x + (sn(tm * 6 + i * 40) >> 7), bu[i].y >> 4, bu[i].r);
    }
}

/* ---------- celula ---------- */
/* A10/B10: semiejes en decimas de pixel. dir=+1 mira a la derecha, -1 a la izquierda. */
static void cell_body(int cx, int cy, int Z, int A10, int B10, int col, int seed) {
    int E = ((A10 > B10 ? A10 : B10) + 9) / 10 + 1;
    int ia = (256 << 12) / (A10 * A10), ib = (256 << 12) / (B10 * B10);
    int vs = 2560 / (E * 14);
    for (int dy = -E; dy <= E; dy++) for (int dx = -E; dx <= E; dx++) {
        int x10 = dx * 10, y10 = dy * 10;
        int d = (x10 * x10 * ia + y10 * y10 * ib) >> 12;
        if (d > 256) continue;
        int v = -(dx + dy) * vs, sh;
        sh = d > 184 ? 3 : v > 72 ? 2 : v > -31 ? 1 : 0;
        rect(cx + dx * Z, cy + dy * Z, Z, Z, (u8)(C_CELL + col * 4 + sh));
    }
    /* organulos */
    for (int i = 0; i < 3; i++) {
        int s = seed * (i + 2);
        int lu = (cs(s * 5) * A10 / 256) * 45 / 1000 + (sn(tm * 2 + s) >> 8) * 1;
        int lv = (sn(s * 8) * B10 / 256) * 45 / 1000 + (cs(tm * 2 + s) >> 8) * 1;
        rect(cx + lu * Z, cy + lv * Z, 2 * Z, 2 * Z, (u8)(C_CELL + col * 4 + 0));
        rect(cx + lu * Z, cy + lv * Z, Z, Z, (u8)(C_CELL + col * 4 + 2));
    }
    /* nucleo */
    int rn = (B10 * 32 / 100 + 5) / 10; if (rn < 2) rn = 2;
    for (int dy = -rn; dy <= rn; dy++) for (int dx = -rn; dx <= rn; dx++) {
        int d2 = (dx * dx + dy * dy) * 100;
        if (d2 > (rn * 10 + 2) * (rn * 10 + 2)) continue;
        int edge = d2 > (rn - 1) * (rn - 1) * 100;
        int sh = edge ? 3 : ((dx + dy) * 10 < -rn * 4 ? 2 : 0);
        rect(cx + dx * Z, cy + dy * Z, Z, Z, (u8)(C_CELL + col * 4 + sh));
    }
}
static void flagelo(int cx, int cy, int Z, int A, int dir, int mv) {
    for (int i = -1; i < 13; i++) {
        int k = (sn(tm * 16 * (10 + mv * 5) / 15 - i * 22) * (i * 28 + 40) / 100) * (100 + mv * 60) / 100 / 256;
        int x = cx - dir * (A + i * Z) , y = cy - k * Z / 1;
        u8 c = i > 10 ? C_PNL2 : C_PNK;
        rect(x, y, Z, Z, c); if (i < 5) rect(x, y + Z, Z, Z, C_PNK3);
    }
}
static void ojo(int x, int y, int dir, int Z) {
    int bl = (tm % 240) < 6;
    for (int v = -2; v <= 2; v++) for (int u = -1; u <= 3; u++) {
        int d = (u - 1) * (u - 1) + v * v;
        if (d <= 4) rect(x + u * dir * Z, y + v * Z, Z, Z, bl ? C_EYED : d >= 3 ? C_EYE : C_WHT);
    }
    if (!bl) { rect(x + 2 * dir * Z, y, Z, Z, C_EYED); rect(x + 1 * dir * Z, y, Z, Z, C_EYED); }
}
static void filtro(int x, int y, int dir, int Z) {
    for (int v = -3; v <= 3; v++) {
        for (int u = 0; u < 4; u++) rect(x + u * dir * Z, y + v * Z, Z, Z, (v & 1) ? C_FIL1 : C_FIL2);
        int w = (sn(tm * 31 / 10 * 1 + v * 40) * 8 / 10) >> 8;
        rect(x + (4 + w) * dir * Z, y + v * Z, Z, Z, C_FIL3);
    }
}
/* celula del jugador (verde, con filtro, flagelo y dos ojos) */
static void draw_me(int cx, int cy, int Z, int dir, int col) {
    int w = 256 + (sn(tm * 11 / 4) * 9 >> 8);        /* 1 + 0.035 sin */
    int A10 = 84 * w >> 8, B10 = 64 * (512 - w) >> 8; /* r=7, el=1.2 */
    int A = A10 * Z / 10;
    flagelo(cx, cy, Z, A, dir, 12);
    cell_body(cx, cy, Z, A10, B10, col, 3);
    filtro(cx + dir * A, cy, dir, Z);
    ojo(cx + dir * 9 * Z / 2, cy + 5 * Z, dir, Z);
    ojo(cx + dir * 9 * Z / 2, cy - 5 * Z, dir, Z);
}
/* enemigo simple (naranja, de cara a la izquierda) */
static void draw_enemy(int cx, int cy, int Z, int dir) {
    int A10 = 78, B10 = 68, A = A10 * Z / 10;
    flagelo(cx, cy, Z, A, dir, 10);
    cell_body(cx, cy, Z, A10, B10, 3, 5);
    ojo(cx + dir * 4 * Z, cy + 4 * Z, dir, Z);
    ojo(cx + dir * 4 * Z, cy - 4 * Z, dir, Z);
}

/* ---------- escenas ---------- */
enum { S_TITLE, S_SOON };
static int scene = S_TITLE, menu;

static void scene_title(void) {
    if (pressed & (K_U | K_D)) menu ^= 1;
    if (pressed & K_A) scene = S_SOON;
    dma32(fb, BG_IMG, SW * SH / 4);
    draw_bubbles();
    int mx = ((tm * 7 / 10) % 330) - 45;
    draw_me(mx & ~1, (118 + (sn(tm * 13 / 4) * 6 >> 8)) & ~1, 2, 1, 0);
    draw_enemy(270 - (tm * 4 / 10) % 330, 30 + (sn(tm * 10) * 8 >> 8), 1, -1);

    static const char L[] = "SPORE";
    for (int i = 0; i < 5; i++) {
        char s[2] = { L[i], 0 };
        int y = 22 + (sn(tm * 15 + i * 41) * 3 >> 8);
        text_sh(s, 84 + i * 16, y, C_LGR, 4, C_DGR);
    }
    text_c("ETAPA CELULAR", 120, 48, C_YEL, 1, C_ORB);
    panel(66, 84, 108, 40);
    static const char *it[2] = { "EDITAR CELULA", "NADAR!" };
    for (int i = 0; i < 2; i++) {
        int y = 93 + i * 14, on = menu == i;
        if (on) { rect(70, y - 3, 100, 11, C_SEL); text(">", 73 + ((tm >> 4) & 1), y, C_YEL, 1); }
        text_c(it[i], 120, y, on ? C_WHT : C_TXT, 1, -1);
    }
    if ((tm >> 5) & 1) text_c("A: ACEPTAR", 120, 140, C_HLP, 1, C_BLK);
}
static void scene_soon(void) {
    if (pressed & K_B) scene = S_TITLE;
    dma32(fb, BG_IMG, SW * SH / 4);
    draw_bubbles();
    panel(40, 50, 160, 50);
    text_c(menu ? "NADAR!" : "EDITAR CELULA", 120, 60, C_YEL, 1, C_BLK);
    text_c("ETAPA 2: EN CONSTRUCCION", 120, 74, C_WHT, 1, -1);
    text_c("B: VOLVER", 120, 88, C_TX2, 1, -1);
}

int main(void) {
    REG_DISPCNT = 4 | (1 << 10); /* Modo 4, BG2 */
    init_palette();
    init_bubbles();
    for (;;) {
        poll();
        tm++;
        if (scene == S_TITLE) scene_title(); else scene_soon();
        present();
    }
}
