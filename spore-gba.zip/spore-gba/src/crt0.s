@ Arranque minimo para GBA (sin libgba). gbafix rellena logo y checksum.
    .section .header, "ax"
    .arm
    .global _start
_start:
    b       start_vector
    .space  156                 @ logo Nintendo (lo escribe gbafix)
    .ascii  "SPORECELULAR"      @ titulo (12)
    .ascii  "ASPE"              @ codigo de juego
    .ascii  "01"                @ fabricante
    .byte   0x96
    .byte   0, 0
    .space  7
    .byte   0                   @ version
    .byte   0                   @ complemento (gbafix)
    .space  2
start_vector:
    mov     r0, #0x1F           @ modo System
    msr     cpsr_c, r0
    ldr     sp, =__sp_usr
    @ copiar .iwram (codigo+datos) de ROM a IWRAM
    ldr     r0, =__iwram_lma
    ldr     r1, =__iwram_start
    ldr     r2, =__iwram_end
1:  cmp     r1, r2
    ldrlo   r3, [r0], #4
    strlo   r3, [r1], #4
    blo     1b
    @ poner a cero .bss
    ldr     r1, =__bss_start
    ldr     r2, =__bss_end
    mov     r3, #0
2:  cmp     r1, r2
    strlo   r3, [r1], #4
    blo     2b
    ldr     r0, =main
    bx      r0
    .pool
