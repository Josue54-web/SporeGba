# SPORE GBA - Etapa Celular

Port a Game Boy Advance del juego HTML. Sin librerias: solo registros de hardware.

## Compilar
Necesitas devkitARM (devkitPro) o cualquier `arm-none-eabi-gcc`, mas `make` y `python3`.

    make          # genera spore.gba
    make regen    # (opcional, requiere python3) regenera src/data.h
    make clean

`gbafix` (incluido en devkitPro) arregla el header para consola real. En emulador no hace falta.

## Controles
D-pad: mover/elegir   A: aceptar   B: volver

## Estado
- [x] Etapa 1: motor, fuente, fondo, pantalla de titulo
- [ ] Etapa 2: editor de celula
- [ ] Etapa 3: juego (nadar, comer, enemigos)
- [ ] Etapa 4: pausa y pulido
