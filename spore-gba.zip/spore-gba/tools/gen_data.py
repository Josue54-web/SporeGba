#!/usr/bin/env python3
"""Genera src/data.h a partir del juego HTML original (fuente 3x5, fondo, tabla de senos)."""
import re, math, sys
html = open(sys.argv[1] if len(sys.argv) > 1 else "SPORE_GBA_-_Etapa_Celular.html", encoding="utf-8").read()
FC = re.search(r'const FC="([^"]*)"', html).group(1)
FD = re.search(r'const FD="([^"]*)"', html).group(1).split(" ")
assert len(FC) == len(FD), (len(FC), len(FD))
W, H = 240, 160
BY = [0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5]
ax  = [math.sin(x*.07) for x in range(W)]
ax2 = [math.sin(x*.045) for x in range(W)]
by  = [math.sin(y*.08) for y in range(H)]
by2 = [math.sin(y*.05) for y in range(H)]
ray = [max(0, math.sin(i*.045))**3 for i in range(W+H)]
bg = []
for y in range(H):
    dp = y/H; base = .12+.42*(1-dp)*(1-dp*.4); ry = .22*(1-dp)
    for x in range(W):
        v = base + ray[x+(y>>1)]*ry
        c = ax[x]+by[y]+ax2[x]*by2[y]
        if abs(c) < .13: v += .2
        v += ax[x]*by[y]*.03
        l = int(v*4.6 + BY[(y&3)*4+(x&3)]/16 - .45)
        bg.append(min(4, max(0, l)) + 1)
with open("src/data.h", "w") as f:
    f.write("/* GENERADO por tools/gen_data.py - no editar a mano */\n#pragma once\n")
    f.write('#define FONT_N %d\nstatic const char FONT_CH[] = "%s";\n' % (len(FC), FC))
    f.write("static const unsigned char FONT_D[FONT_N][5] = {\n")
    for d in FD: f.write("  {%s},\n" % ",".join(d))
    f.write("};\n")
    f.write("static const signed short SINTAB[256] = {\n")
    f.write(",".join(str(round(math.sin(i/256*2*math.pi)*256)) for i in range(256)) + "\n};\n")
    f.write("static const unsigned char BG_IMG[%d] __attribute__((aligned(4))) = {\n" % (W*H))
    for i in range(0, W*H, 40): f.write(",".join(map(str, bg[i:i+40])) + ",\n")
    f.write("};\n")
print("src/data.h OK")
